# TalkSphare

A Pen created on CodePen.io. Original URL: [https://codepen.io/rclhntvf-the-typescripter/pen/WNVRVOZ](https://codepen.io/rclhntvf-the-typescripter/pen/WNVRVOZ).

